<?php
namespace App\Controllers;

class Controller 
{
	
	public function response()
	{

	}
}